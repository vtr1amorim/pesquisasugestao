document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');
    const errorMessage = document.getElementById('error-message');
    const languageButtons = document.querySelectorAll('.language-button');

    loginForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Impede o envio do formulário

        const cpf = document.getElementById('cpf').value;

        if (!cpf) {
            errorMessage.innerText = translations[currentLang]['cpfError'];
            return;
        }

        // Envia o CPF via POST para o backend
        fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cpf })
        })
        .then(response => response.json())
        .then(data => {
            if (data.redirecionar) {
                // Armazena o CPF no local storage
                localStorage.setItem('cpf', data.cpf);

                // Redireciona para a página de pesquisa caso o login seja bem-sucedido
                window.location.href = data.redirecionar;
            } else {
                errorMessage.innerText = data.erro || translations[currentLang]['unknownError'];
            }
        })
        .catch(error => {
            console.error('Erro no login:', error);
            errorMessage.innerText = translations[currentLang]['loginError'];
        });
    });

    languageButtons.forEach(button => {
        button.addEventListener('click', () => {
            const lang = button.id;
            switchLanguage(lang);
        });
    });

    function switchLanguage(lang) {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            element.innerText = translations[lang][key] || element.innerText;
        });
        const placeholders = document.querySelectorAll('[data-translate-placeholder]');
        placeholders.forEach(element => {
            const key = element.getAttribute('data-translate-placeholder');
            element.placeholder = translations[lang][key] || element.placeholder;
        });
        currentLang = lang;
    }

    const translations = {
        'pt-br': {
            'loginTitle': 'Pesquisa Dom Porquito',
            'cpfLabel': 'A resposta é confidencial e anônima, sua opinião é importante.',
            'cpfPlaceholder': 'Digite seu CPF',
            'loginButton': 'Entrar',
            'cpfError': 'Por favor, insira seu CPF.',
            'unknownError': 'Erro desconhecido.',
            'loginError': 'Erro ao fazer login, tente novamente mais tarde.'
        },
        'es-es': {
            'loginTitle': 'Encuesta Dom Porquito',
            'cpfLabel': 'La respuesta es confidencial y anónima, su opinión es importante.',
            'cpfPlaceholder': 'Ingrese su CPF',
            'loginButton': 'Entrar',
            'cpfError': 'Por favor, ingrese su CPF.',
            'unknownError': 'Error desconocido.',
            'loginError': 'Error al iniciar sesión, inténtelo de nuevo más tarde.'
        }
    };

    let currentLang = 'pt-br'; // Define o idioma padrão como português
    switchLanguage(currentLang); // Aplica o idioma padrão
});