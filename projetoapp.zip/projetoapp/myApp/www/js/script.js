document.addEventListener('DOMContentLoaded', function() {
    const perguntas = document.querySelectorAll('.pergunta');
    const submitButton = document.getElementById('submit-button');
    const agradecimento = document.getElementById('agradecimento');
    const logoffButton = document.getElementById('logoff-button');
    const languageButtons = document.querySelectorAll('.language-button');
    let currentLang = 'pt-br'; // Define o idioma padrão como português
    let currentQuestionIndex = 0;

    perguntas.forEach((pergunta, index) => {
        const nextButton = pergunta.querySelector('.next-button');
        nextButton.addEventListener('click', () => {
            const select = pergunta.querySelector('input[type="radio"]:checked');
            if (select) {
                perguntas[currentQuestionIndex].style.display = 'none';
                currentQuestionIndex++;
                if (currentQuestionIndex < perguntas.length) {
                    perguntas[currentQuestionIndex].style.display = 'block';
                } else {
                    submitButton.style.display = 'block';
                }
            } else {
                alert(translations[currentLang]['selectError']);
            }
        });

        const radioButtons = pergunta.querySelectorAll('input[type="radio"]');
        radioButtons.forEach((input) => {
            input.addEventListener('change', () => {
                const value = parseInt(input.value, 10);
                radioButtons.forEach((rb, idx) => {
                    const label = pergunta.querySelector(`label[for="${rb.id}"] .estrela`);
                    if (idx < value) {
                        label.style.color = getColor(value);
                    } else {
                        label.style.color = '#ccc';
                    }
                });
            });
        });
    });

    function getColor(value) {
        switch (value) {
            case 1:
                return '#ff0000';
            case 2:
                return '#ff6666';
            case 3:
                return '#ffff00';
            case 4:
                return '#66ff66';
            case 5:
                return '#00ff00';
            default:
                return '#ccc';
        }
    }

    document.getElementById('pesquisaForm').addEventListener('submit', function(event) {
        event.preventDefault();
        const formData = new FormData(this);
        const respostas = [];
        for (let [name, value] of formData.entries()) {
            const perguntaId = name.split('_')[1];
            respostas.push({ perguntaId, respostaId: value });
        }

        const cpf = localStorage.getItem('cpf');
        fetch('/pesquisa', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ cpf, respostas })
        })
        .then(response => response.json())
        .then(data => {
            if (data.mensagem) {
                agradecimento.style.display = 'block';
                document.getElementById('pesquisaForm').style.display = 'none';

                // Redirecionar para a página de login após 3 segundos
                setTimeout(() => {
                    window.location.href = '/login';
                }, 3000);
            } else {
                alert('Erro ao enviar respostas. Tente novamente.');
            }
        })
        .catch(error => {
            console.error('Erro ao enviar respostas:', error);
            alert('Erro ao enviar respostas. Tente novamente.');
        });
    });

    logoffButton.addEventListener('click', function() {
        localStorage.removeItem('cpf');
        window.location.href = '/login';
    });

    languageButtons.forEach(button => {
        button.addEventListener('click', () => {
            const lang = button.id;
            switchLanguage(lang);
        });
    });

    function switchLanguage(lang) {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            element.innerText = translations[lang][key] || element.innerText;
        });
        currentLang = lang;
    }

    const translations = {
        'pt-br': {
            'title': 'Pesquisa de Satisfação',
            'next': 'Próxima',
            'submit': 'Enviar Respostas',
            'thankyou': 'Obrigado pela sua atenção!',
            'logoff': 'Logoff',
            'selectError': 'Por favor, selecione uma resposta.',
            'veryDissatisfied': 'Muito Insatisfeito',
            'dissatisfied': 'Insatisfeito',
            'neutral': 'Neutro',
            'satisfied': 'Satisfeito',
            'verySatisfied': 'Muito Satisfeito'
        },
        'es-es': {
            'title': 'Encuesta de Satisfacción',
            'next': 'Siguiente',
            'submit': 'Enviar Respuestas',
            'thankyou': '¡Gracias por su atención!',
            'logoff': 'Cerrar sesión',
            'selectError': 'Por favor, seleccione una respuesta.',
            'veryDissatisfied': 'Muy Insatisfecho',
            'dissatisfied': 'Insatisfecho',
            'neutral': 'Neutral',
            'satisfied': 'Satisfecho',
            'verySatisfied': 'Muy Satisfecho'
        }
    };

    switchLanguage(currentLang); // Aplica o idioma padrão
});