# MyApp

An example Apache Cordova application.

## Estrutura do Projeto

```
myApp/
├── hooks/
├── node_modules/
├── platforms/
├── plugins/
├── www/
│   ├── css/
│   │   ├── style.css
│   │   └── login.css
│   ├── js/
│   │   ├── script.js
│   │   └── login.js
│   ├── images/
│   │   └── logo.png
│   ├── login.html
│   ├── pesquisa.ejs
│   ├── server.js
│   └── index.html
├── config.xml
├── package.json
└── README.md
```

## Comandos

- `npm install` - Instalar dependências
- `cordova platform add android` - Adicionar a plataforma Android
- `cordova build android` - Construir o APK
- `npm start` - Iniciar o servidor