import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import oracledb from 'oracledb';

// Configurar Oracle (se necessário)
oracledb.initOracleClient();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Middleware para JSON e arquivos estáticos
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Configurar o motor de templates
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configuração do banco
const dbConfig = {
    user: 'dpateste',
    password: 'tecsis',
    connectString: '172.17.200.250:1521/DPATESTE'
};

// Testar conexão inicial
async function testarConexao() {
    try {
        const connection = await oracledb.getConnection(dbConfig);
        console.log("✅ Conectado ao Oracle!");
        await connection.close();
    } catch (err) {
        console.error("❌ Erro ao conectar ao Oracle:", err);
    }
}
testarConexao();

// Rota para a página de login
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html')); // Serve o login.html na raiz
});

// Adiciona a rota para a página de login
app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html')); // Serve o login.html na rota /login
});

// Rota para a página de pesquisa de satisfação
app.get('/pesquisa', async (req, res) => {
    try {
        const connection = await oracledb.getConnection(dbConfig);
        const perguntasResult = await connection.execute(`SELECT IDPES, PERGUNTA FROM AD_PESQSAT`);
        const respostasResult = await connection.execute(`SELECT IDRES, RESPOSTAS FROM AD_RESSAT`);
        await connection.close();

        console.log("✅ Perguntas obtidas com sucesso!", perguntasResult.rows);
        console.log("✅ Respostas obtidas com sucesso!", respostasResult.rows);

        // Renderiza o HTML com as perguntas e respostas
        res.render('pesquisa', { perguntas: perguntasResult.rows, respostas: respostasResult.rows });
    } catch (err) {
        console.error('❌ Erro ao buscar perguntas e respostas:', err);
        res.status(500).json({ erro: 'Erro ao buscar perguntas e respostas.' });
    }
});

// Rota de login (CPF)
app.post('/login', async (req, res) => {
    const { cpf } = req.body;
    console.log('Tentando fazer login com CPF:', cpf); // Verifique se está recebendo o CPF correto

    try {
        const connection = await oracledb.getConnection(dbConfig);
        const result = await connection.execute(
            `SELECT CPF FROM TFPFUN WHERE CPF = :cpf`,
            [cpf]
        );

        await connection.close();

        if (result.rows.length > 0) {
            // CPF encontrado, armazenar o CPF no armazenamento local e redirecionar para a pesquisa
            console.log('Login bem-sucedido, CPF encontrado!');
            res.json({ mensagem: "Login bem-sucedido!", redirecionar: "/pesquisa", cpf });
        } else {
            console.log('CPF não encontrado no banco.');
            res.status(401).json({ erro: "CPF não encontrado!" });
        }
    } catch (err) {
        console.error('❌ Erro no login:', err);
        res.status(500).json({ erro: 'Erro ao processar o login.' });
    }
});

// Rota para inserir respostas
app.post('/pesquisa', async (req, res) => {
    const { cpf, respostas } = req.body; // Certifique-se de que o CPF está sendo passado corretamente

    try {
        const connection = await oracledb.getConnection(dbConfig);

        // Obter o CODFUNC a partir do CPF
        const resultFunc = await connection.execute(
            `SELECT CODFUNC FROM TFPFUN WHERE CPF = :cpf`,
            [cpf]
        );

        if (resultFunc.rows.length > 0) {
            const codFunc = resultFunc.rows[0][0];
            const codEmp = 5; // Assumindo que CODEMP é 5

            // Obter o maior valor de IDSAT
            const resultMaxId = await connection.execute(
                `SELECT NVL(MAX(IDSAT), 0) + 1 AS MAX_ID FROM AD_PESQSATISINT`
            );
            let nextIdSat = resultMaxId.rows[0][0];

            for (const resposta of respostas) {
                const { perguntaId, respostaId } = resposta;

                // Inserir a resposta na tabela AD_PESQSATISINT
                await connection.execute(
                    `INSERT INTO AD_PESQSATISINT (IDSAT, CODEMP, CODFUNC, IDPES, IDRES) 
                     VALUES (:nextIdSat, :codEmp, :codFunc, :perguntaId, :respostaId)`,
                    { nextIdSat, codEmp, codFunc, perguntaId, respostaId }
                );
                nextIdSat++; // Incrementar o IDSAT para o próximo registro
            }

            await connection.commit();
            await connection.close();

            res.json({ mensagem: "Respostas registradas com sucesso!" });
        } else {
            console.log('CODFUNC não encontrado para o CPF.');
            res.status(401).json({ erro: "CODFUNC não encontrado!" });
        }
    } catch (err) {
        console.error('❌ Erro ao registrar respostas:', err);
        res.status(500).json({ erro: 'Erro ao registrar respostas.' });
    }
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://127.0.0.1:${PORT}`);
});